package com.example.notekeeper;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.List;

public class NoteActivity extends AppCompatActivity {
    public static final String NOTE_POSITION = "com.example.noteKeeper.NOTE_POSITION";
    public static  final String ORIGINAL_NOTE_COURSE_ID = "com.example.noteKeeper.ORIGINAL_NOTE_COURSE_ID";
    public static  final String ORIGINAL_NOTE_TITLE = "com.example.noteKeeper.ORIGINAL_NOTE_TITLE";
    public static final String ORIGINAL_NOTE_TEXT = "com.example.noteKeeper.ORIGINAL_NOTE_TEXT";
    public static final int POSITION_NOT_SET = -1;
    private NoteInfo mNotes;
    private Boolean isNewNote;
    private Spinner spinnerCourses;
    private EditText textNoteTitle;
    private EditText textNoteText;
    private int notePosition;
    private boolean isCancelling;
    private String originalNoteTitle;
    private String originalNoteText;
    private String originalNoteCourseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        spinnerCourses = findViewById(R.id.spinner_courses);

        List<CourseInfo> courses = DataManager.getInstance().getCourses();

        ArrayAdapter<CourseInfo> adapterCourses = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,courses);

        adapterCourses.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCourses.setAdapter(adapterCourses);

        readDisplayStateValues();
        if(savedInstanceState == null) {
            saveOriginalNoteValues();
        }else {
            restoreOriginalNoteValues(savedInstanceState);
        }
        textNoteTitle = findViewById(R.id.textnotetitle);
        textNoteText = findViewById(R.id.textnotetext);
        if(!isNewNote)
            displayNote(spinnerCourses, textNoteTitle, textNoteText);
    }

    private void restoreOriginalNoteValues(Bundle savedInstanceState) {
        originalNoteCourseId = (String) savedInstanceState.get(ORIGINAL_NOTE_COURSE_ID);
        originalNoteTitle = (String) savedInstanceState.get(ORIGINAL_NOTE_TITLE);
        originalNoteText = (String) savedInstanceState.get(ORIGINAL_NOTE_TITLE);

    }

    private void saveOriginalNoteValues() {
        if(isNewNote)
            return;
        originalNoteCourseId = mNotes.getCourse().getCourseId();
        originalNoteTitle = mNotes.getTitle();
        originalNoteText = mNotes.getText();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(isCancelling){
            if(isNewNote){

                DataManager.getInstance().removeNote(notePosition);
            }else { storePreviousNoteValues();
            }
        }else {
            saveNote();
        }
    }

    private void storePreviousNoteValues() {
        CourseInfo coursesNote = DataManager.getInstance().getCourse(originalNoteCourseId);
        mNotes.setCourse(coursesNote);
        mNotes.setTitle(originalNoteTitle);
        mNotes.setText(originalNoteText);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(ORIGINAL_NOTE_COURSE_ID, originalNoteCourseId);
        outState.putString(ORIGINAL_NOTE_TITLE , originalNoteTitle);
        outState.putString(ORIGINAL_NOTE_TEXT, originalNoteText);
    }

    private void saveNote() {
            mNotes.setCourse((CourseInfo) spinnerCourses.getSelectedItem()) ;
            mNotes.setTitle(textNoteTitle.getText().toString());
            mNotes.setText(textNoteText.getText().toString());
    }

    private void displayNote(Spinner spinnerCourses, EditText textNoteTitle, EditText textNoteText) {
        List<CourseInfo> courses = DataManager.getInstance().getCourses();
        int courseIndex = courses.indexOf(mNotes.getCourse());
        spinnerCourses.setSelection(courseIndex);
        textNoteTitle.setText(mNotes.getTitle());
        textNoteText.setText(mNotes.getText());
    }
    private void readDisplayStateValues() {
        Intent intent = getIntent();
        int position  = intent.getIntExtra(NOTE_POSITION, POSITION_NOT_SET);
        isNewNote = position == POSITION_NOT_SET;
        if(isNewNote){
            createNewNote();
        }else {
        mNotes = DataManager.getInstance().getNotes().get(position);
        }
    }

    private void createNewNote() {
        DataManager dm = DataManager.getInstance();
        notePosition = dm.createNewNote();
        mNotes = dm.getNotes().get(notePosition);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_note, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_send_mail) {
            sendEmail();
            return true;
        }else if (id == R.id.action_cancel){
            isCancelling = true;
            finish();
        }else if(id == R.id.action_next){
            moveNext();


        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem item = menu.findItem(R.id.action_next);
//        MenuItem itemPrev = menu.findItem(R.id.action_prev);
//        int firstNoteIndex = DataManager.getInstance().getNotes().size()+1;
        int lastNoteIndex = DataManager.getInstance().getNotes().size() - 1;
//        itemPrev.setEnabled(notePosition >= firstNoteIndex);
        item.setEnabled(notePosition <  lastNoteIndex);
        return super.onPrepareOptionsMenu(menu);
    }

    private void moveNext() {
        saveNote();
        ++notePosition;
        mNotes = DataManager.getInstance().getNotes().get(notePosition);
        saveOriginalNoteValues();
        displayNote(spinnerCourses,textNoteTitle, textNoteText);
        invalidateOptionsMenu();
    }

//    private void previousNext() {
//        saveNote();
//        --notePosition;
//        mNotes = DataManager.getInstance().getNotes().get(notePosition);
//        saveOriginalNoteValues();
//        displayNote(spinnerCourses,textNoteTitle, textNoteText);
//        invalidateOptionsMenu();
//    }


    private void sendEmail() {
        CourseInfo course = (CourseInfo) spinnerCourses.getSelectedItem();
        String subject = textNoteTitle.getText().toString();
        String text = "Checkout what i learned today at PDG School\"" + course.getTitle() + "\"\n"
                + textNoteText.getText().toString();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("massage/rcf2822");
        intent.putExtra(Intent.EXTRA_SUBJECT,subject);
        intent.putExtra(Intent.EXTRA_TEXT, text);
        startActivity(intent);
    }
}
