package com.example.notekeeper;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;
import java.util.List;

public class NoteListActivity extends AppCompatActivity {
    private NoteRecyclerAdapter noteRecyclerAdapter;
    //    private NoteRecyclerAdapter mNoteRecyclerAdapter;

//    private ArrayAdapter<NoteInfo> adapterNotes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Context context = getApplicationContext();
                CharSequence textToShow  = "creating new Note..";
                int timeToLoad = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context,textToShow,timeToLoad);
                toast.show();
               startActivity(new Intent(NoteListActivity.this, NoteActivity.class));
            }
        });

        initializeDisplayContent();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
//        adapterNotes.notifyDataSetChanged();
         noteRecyclerAdapter.notifyDataSetChanged();
    }

        private void initializeDisplayContent() {
//       final ListView listNote = findViewById(R.id.list_notes);
//       List<NoteInfo> notes = DataManager.getInstance().getNotes();
//
//       adapterNotes = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,notes);
//       listNote.setAdapter(adapterNotes);
//
//        listNote.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//          @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//                Intent intent = new Intent(NoteListActivity.this,NoteActivity.class);
//                NoteInfo note = (NoteInfo) listNote.getItemAtPosition(position);
//                intent.putExtra(NoteActivity.NOTE_POSITION, position);
//                startActivity(intent);
//                       }
//        });
            RecyclerView recyclerNotes = findViewById(R.id.list_notes);
            LinearLayoutManager notesLayoutManager = new LinearLayoutManager(this );
            recyclerNotes.setLayoutManager(notesLayoutManager);

            List<NoteInfo> notes = DataManager.getInstance().getNotes();
            noteRecyclerAdapter = new NoteRecyclerAdapter(this,notes);
            recyclerNotes.setAdapter(noteRecyclerAdapter);
    }




}
